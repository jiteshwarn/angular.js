describe("Testing compile service", function() {
	var element;
	var $scope;
	beforeEach(inject(function($compile, $rootScope) {
		$scope = $rootScope;
		element = angular.element("<div>{{2 + 2}}</div>");
		element = $compile(element)($rootScope)
	}));
	
	it('should equal 4', function() {
		$scope.$digest() // <div>4</div>
		expect(element.html()).toBe("4");
	});
})