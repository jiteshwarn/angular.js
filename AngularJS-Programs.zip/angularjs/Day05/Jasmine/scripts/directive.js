var app = angular.module('directiveApp',[]);

app.directive('igateMouseEnter',function(){
	return {
		restrict:'EA',
		link:function(scope,element,attrs){
			console.log(scope,element,attrs);
			element.bind('mouseenter',function(){
				element.addClass(attrs.customStyle);
			});
		}
	}
});

app.directive('igateMouseLeave',function(){
	/*Link function*/
	return function(scope,element,attrs){
		 element.bind('mouseleave',function(){
				element.removeClass(attrs.customStyle);
		});
	}
});

app.controller('MyCtrl',function($scope){
	$scope.name = "ChildScope";
	$scope.$parent.name = "RootScope";
});

		