var app = angular.module('testApp');

app.directive('igateMouseEnter',function(){
	return {
		restrict:'EA',
		link:function(scope,element,attrs){
			element.bind('mouseenter',function(){
				element.addClass(attrs.customStyle);
			});
		}
	}
});

app.directive('igateMouseLeave',function(){
	/*Link function*/
	return function(scope,element,attrs){
		 element.bind('mouseleave',function(){
				element.removeClass(attrs.customStyle);
		});
	}
});


		