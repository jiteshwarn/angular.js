describe("Testing Custom Directive", function() {
	var rootScope;
	var scope;
	var myCtrl;
	var element;
	beforeEach(module('directiveApp'));
	
	beforeEach(inject(function($controller,$rootScope,$compile){
		rootScope = $rootScope;
		scope = rootScope.$new();
		myCtrl = $controller('MyCtrl',{$scope:scope});
		var dom = '<input type="button" data-igate-mouse-enter data-igate-mouse-leave value="Click" data-custom-style="custom"/>'
		element = $compile(dom)(rootScope);
	}));
	
	it('should have the value ChildScope and RootScope for the name key attached to scope and rootScope',function(){
		expect(scope.name).toEqual('ChildScope');
		expect(rootScope.name).toEqual('RootScope');
	});
	
	it('should add a custom class named \'custom\' when the mouse pointer enter the element',function(){
		element.trigger('mouseenter');
		expect(element.hasClass('custom')).toBe(true);
	});
	
	it('should remove the custom class named \'custom\' when the mouse pointer leaves the element',function(){
		element.trigger('mouseleave');
		expect(element.hasClass('custom')).toBe(false);
	});
	
	
});