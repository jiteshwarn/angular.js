'use strict';

describe('my app', function() {


  it('should automatically redirect to home page', function() {
    browser.get('view/Routing.html');
    expect(browser.getLocationAbsUrl()).toMatch("/");
  });
  
  
  it('should match the title', function() {
    expect(browser.getTitle()).toMatch("Testing Routing");
  });
  
   it('should change the view to trainerInfo when that button gets clicked', function() {
    var button = element(by.id('btnTrainer'));
	button.click();
	expect(browser.getLocationAbsUrl()).toMatch("/trainer");
  });
  
  it('should bind email to the span and textbox when setEmail button clicked', function() {
    var button = element(by.id('btnEmail'));
	var spanElement = element(by.binding('emailId'));
	var input = element(by.model('emailId'));
	
	button.click();
	expect(spanElement.getText()).toBe("karthik.muthukrishnan@igate.com");
	expect(input.getAttribute('value')).toBe("karthik.muthukrishnan@igate.com");
  });
  
  it('should clear the textbox and change the value to Thank you All', function() {
	var input = element(by.model('emailId'));
	input.clear();
	input.sendKeys('Thank you All');
	expect(input.getAttribute('value')).toBe("Thank you All");
  });
  

});
