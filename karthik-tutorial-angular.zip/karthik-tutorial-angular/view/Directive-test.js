describe("Testing Custom Directive", function() {
	var rootScope;
	var scope;
	var element;
	beforeEach(module('testApp'));
	
	beforeEach(inject(function($controller,$rootScope,$compile){
		rootScope = $rootScope;
		scope = rootScope.$new();
		var dom = '<input type="button" data-igate-mouse-enter data-igate-mouse-leave value="Click" data-custom-style="custom"/>'
		element = $compile(dom)(rootScope);
	}));
	
	it('should add a custom class named \'custom\' when the mouse pointer enter the element',function(){
		element.trigger('mouseenter');
		expect(element.hasClass('custom')).toBe(true);
	});
	
	it('should remove the custom class named \'custom\' when the mouse pointer leaves the element',function(){
		element.trigger('mouseleave');
		expect(element.hasClass('custom')).toBe(false);
	});
	
	
});