describe("Testing Controller", function() {
	var myController;
	var scope;
	var rootScope;
	
	beforeEach(module('testApp'));
	
	beforeEach(inject(function($controller,$rootScope){
		rootScope = $rootScope;
		scope = rootScope.$new();
		myController = $controller('MyCtrl',{$scope:scope});
	}));
	
	it('should have controller named MyCtrl',function(){
		expect(myController).toBeDefined();
	});
	
	it('should have the value Karthik for name key in the employee model attached to scope',function(){
		
		expect(scope.employee.name).toEqual('Karthik');
	});
	
	it('should change the name from karthik to anil when changeName function is called',function(){
		scope.changeName();
		expect(scope.employee.name).toEqual('Anil')
	});
});