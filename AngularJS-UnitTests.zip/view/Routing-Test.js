describe("Testing Service", function() {
	var rootScope;
	var scope;
	var roteController;
	
	beforeEach(module('testApp'));
	
	beforeEach(inject(function($controller,$rootScope){
		rootScope = $rootScope;
		scope = rootScope.$new();
		serviceController = $controller('RouteCtrl',{$scope:scope});
	}));
	
	it('should have a scope with company as key deined with a value',function(){
		expect(scope.company).toBeDefined();
		expect(scope.company).toEqual('IGATE');
		
	});
	
	it('should have abind the email to emailId Model',function(){
		scope.setEmail('karthik.muthukrishnan@igate.com')
		expect(scope.emailId).toEqual('karthik.muthukrishnan@igate.com');
		
	});
	
	describe('Testing Routing',function(){
		var $route,$location,$httpBackend;
		
		beforeEach(inject(function(_$route_,_$location_,_$httpBackend_){
			$route = _$route_;
			$location = _$location_;
			$httpBackend = _$httpBackend_;
			
			//$httpBackend .expectGET('/');
			$location.path('/')
			rootScope.$digest();
			
		}));
	
		it('should load the route named country',function(){
			scope.loadPage('country');
			rootScope.$digest();
			expect($location.path()).toBe('/country');
		});
		
		it('should have RouteCtrl as root\'s controller',function(){
			expect($route.routes['/'].controller).toEqual('RouteCtrl');
			expect($route.current.controller).toEqual('RouteCtrl');
			
		});
		
		it('should have partials/trainer.html(partialview) as its tempalateUrl',function(){
			expect($route.routes['/trainer'].templateUrl).toEqual('partials/trainer.html');
		});
		
		it('should redirect to root page when passed with invalid route',function(){
		   // $httpBackend.expectGET('/InvalidRoute');
			$location.path('/InvalidRoute')
			rootScope.$digest();
			expect($location.path()).toBe('/');
		});
		
	});
});