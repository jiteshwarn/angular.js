app.controller('FilterCtrl',function($scope,$filter){
	$scope.name = "KARTHIK";
	$scope.names = ["Anil","Ganesh","Karthik"];
	$scope.today = new Date();
	$scope.time = $filter('date')(new Date(),'hh:mm:ss')
	$scope.favTrainer = $filter('printUpper')('ganesh');
	$scope.results = $filter('arrayFilter')([1,2,4,5,7,8,9],'even');
});